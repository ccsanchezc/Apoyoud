<?php $__env->startSection('content'); ?>
<div class="container">
      
        <div class="row centered-form">
        <div class="center">
        	<div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Agregar Servicio Social: <?php echo e($user->nombre." ". $user->apellido); ?></h3>
			 			</div>
			 			<div class="panel-body">
			    		<?php echo Form::model($user,['route'=>['serviusu.update',$user->codigo],'method'=>'PUT']); ?>

			    		   
			    		<div class="row">
			    				<div class="col-xs-6 col-sm-6 col-md-6">
                            <div class="form-group">
                             <?php echo Form::text('nombre',null,['id'=>'nombre', 'class'=>'form-control ', 'disabled','placeholder'=>'Nombres']); ?>

			               
			    					</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<?php echo Form::text('apellido',null,['id'=>'apellido', 'class'=>'form-control' , 'disabled','placeholder'=>'Apellidos']); ?>

			    					</div>
			    				</div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
                                    <div class="form-group">
                                    <?php echo Form::text('codigo',null,['id'=>'codigo', 'class'=>'form-control', 'disabled','placeholder'=>'Código de Estudiante']); ?>

                                </div>
                                </div>
                                   
			    		</div>
			    		<div class="row">

                            
                            <div class="form-group">
                             <?php echo Form::hidden('Servi_id',$serviid,null,['id'=>'Servi_id', 'class'=>'form-control ', 'disabled','placeholder'=>'Id del servicio social']); ?>

			               
                                </div>
			               
			    				 <div class="form-group">
                                    <?php echo e(Form::hidden('Servi_nombre',$serviciosocial,null, ['class'=>'form-control', 'disabled','placeholder'=>'Nombre del servicio social'])); ?>

                                            
                                 </div>      
			    		</div>
			    			<?php echo Form::submit('Agregar',['class'=>'btn btn-info btn-block']); ?>

			    		    
			    	    <?php echo Form::close(); ?>

			    	  
			    	</div>
	    		</div>
    		</div>
    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>