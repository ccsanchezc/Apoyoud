<?php $__env->startSection('content'); ?>
<!-- /.row -->
           
           
        <?php if(Session::has('message')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
 <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span> </button>
 <?php echo e(Session::get('message')); ?>


</div>
<?php endif; ?>   
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Usuarios plataforma
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-responsive table-hover" id="tabla-User">
                                 <?php echo link_to_route('user.create', 'Crear nuevo usuario', null, ['class'=>'btn btn-success ']); ?>

                                <thead>
                                    <tr>
                                        <th>Código</th>
                                        <th>Nombre</th>
                                        <th>Apellido</th>
                                        <th>Email</th>
                                        <th>Telefono</th>
                                        <th>Dirección</th>
                                        <th>Carrera</th>
                                        <th>Rol</th>
                                        <th>Tipo de Subsidio</th>
                                        <th>Servicio Social</th>
                                        <th>Operación</th>
                                    </tr>
                                </thead>
                               
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr class="gradeX">
                                        <td><?php echo e($user->codigo); ?></td>
                                        <td><?php echo e($user->nombre); ?></td>
                                        <td><?php echo e($user->apellido); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->telefono); ?></td>
                                        <td><?php echo e($user->direccion); ?></td>
                                        <td><?php echo e($user->carrera); ?></td>
                                        <td><?php echo e($user->type); ?></td>
                                        <?php if(!empty($user->sub_usuario)): ?>
                                        <td><?php echo e($user->sub_usuario->type); ?></td>
                                        <?php else: ?>
                                        <td>NO APLICA</td>
                                        <?php endif; ?>
                                        <?php if(!empty($user->servi_usuario)): ?>
                                        <td><?php echo e($user->servi_usuario->nombre.":  ".$user->servi_usuario->descripcion); ?></td>
                                        <?php else: ?>
                                        <td>NO APLICA</td>
                                        <?php endif; ?>
                                        
                                        <td><?php echo link_to_route('user.edit', 'Editar', $user->codigo,  ['class'=>'btn btn-primary']); ?>

                                      <?php echo link_to_route('user.destroy', 'Eliminar', $user->codigo,  ['onclick'=>"return confirm('¿Desea Eliminarlo?')" , 'class'=>'btn btn-danger']); ?>

                                      </td>
                                        
                                       
                                    </tr>
                                </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </table>
                            <!-- /.table-responsive -->
                            <?php echo $users->render(); ?>

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
          
        </div>
        <!-- /#page-wrapper -->

    </div>
    
    
    <!-- /#wrapper -->
    <!--<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>" charset="utf-8"></script>
    
     <script src="<?php echo e(asset('vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>" charset="utf-8"></script>-->
     
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>