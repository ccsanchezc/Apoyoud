<?php $__env->startSection('content'); ?>
<?php if(count($errors) > 0): ?>
   <div class="alert alert-danger" role="alert">
   <ul>
   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   		<li><?php echo e($error); ?></li>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </ul>
</div>
<?php endif; ?>
<div class="container">
      
        <div class="row centered-form">
        <div class="center">
        	<div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Registrar Servicio</h3>
			 			</div>
			 			<div class="panel-body">
			    		<?php echo Form::open(['route'=>'serviA.store','method'=>'POST']); ?>

			    		     
                            
			    			<div class="form-group">
			    				<?php echo Form::text('nombre',null,['id'=>'nombre', 'class'=>'form-control','placeholder'=>'Nombre']); ?>

			    			</div>

			    			<div class="form-group">
			    			<?php echo Form::text('descripcion',null,['id'=>'descripcion', 'class'=>'form-control','placeholder'=>'Descripción']); ?>

			    	    </div>
			    			
			    		   
			    			<?php echo Form::submit('Registrar',['class'=>'btn btn-info btn-block']); ?>

			    		    
			    	    <?php echo Form::close(); ?>

			    	</div>
	    		</div>
    		</div>
    	</div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>