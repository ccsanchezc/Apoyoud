<?php $__env->startSection('content'); ?>
 
 <div id="msj-success"  class="alert alert-success alert-dismissible" role="alert" style="display:none">
  <strong>Estudiante </strong> Registrado listo para recibir almuerzo.
</div>
  <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Usuarios plataforma
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                           <?php echo Form::open(); ?>

                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
                            <?php echo Form::text('codigo',null,['id'=>'codigoe', 'class'=>'form-control','placeholder'=>'Código de Estudiante']); ?>

                            		
			    			<?php echo link_to('#', 'Buscar', ['id'=>'registro','class'=>'btn btn-primary',null]); ?>

			    		    <?php echo link_to('#', 'Registrar', ['id'=>'daralmuerzo','class'=>'btn btn-success',null]); ?>

			    	   
                        </div>
                        <!-- /.panel-body -->
                        
                    </div>
                    <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-responsive table-hover" id="tabla-entrega">
                                
                                <thead>
                                    <tr>
                                        <th>Código</th>
                                        <th>Nombre</th>
                                        <th>Apellido</th>
                                        <th>Carrera</th>
                                       </tr>
                                </thead>
                               
                               
                                <tbody id="datostablae">
                                    
                                </tbody>
                                
                               
                            </table>
                            <!-- /.table-responsive -->
                        </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
          
        </div>
        <!-- /#page-wrapper -->

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>