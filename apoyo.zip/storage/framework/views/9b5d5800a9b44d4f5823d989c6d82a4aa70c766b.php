<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
     


    <title>Inicio Apoyo </title>
   
    <?php echo Html::style('vendor/bootstrap/css/bootstrap.min.css'); ?>

   <?php echo Html::style('vendor/metisMenu/metisMenu.min.css'); ?>

    <?php echo Html::style('css/sb-admin.css'); ?>

     <?php echo Html::style('vendor/font-awesome/css/font-awesome.min.css'); ?>

     <?php echo Html::style('css/morris.css'); ?>

     <?php echo Html::style('css/registeruseradmin.css'); ?>

     <?php echo Html::style('vendor/datatables-plugins/dataTables.bootstrap.css'); ?>

    <?php echo Html::style('vendor/datatablesresponsive/dataTables.responsive.css'); ?>


  
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.min.css" />


     <link type='text/css” href=”css/smoothness/jquery-ui-1.7.1.custom.css' rel='stylesheet' />



 
  <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet">  
   
    <!-- Bootstrap Core CSS -->
   

    <!-- MetisMenu CSS 
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

-->
    <!-- Custom CSS -->
   

    <!-- Morris Charts CSS 
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">
-->
    <!-- Custom Fonts -->


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/">Home</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu message-dropdown">
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading"><strong>John Smith</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading"><strong>John Smith</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading"><strong>John Smith</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-footer">
                            <a href="#">Read All New Messages</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>
          <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->nombre. " ". Auth::user()->apellido); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="<?php echo URL::to('/inicio'); ?>"><i class="fa fa-fw fa-dashboard"></i> Inicio</a>
                    </li>
                    <li>
                        <a href="<?php echo URL::to('/admin/user'); ?>"><i class="fa fa-fw fa-bar-chart-o"></i> Usuario</a>
                    </li>
                    <li>
                        <a href="<?php echo URL::to('/admin/servi'); ?>"><i class="fa fa-fw fa-table"></i> Servicio social</a>
                    </li>
                    <li>
                        <a href="<?php echo URL::to('/admin/sub'); ?>"><i class="fa fa-fw fa-edit"></i>Subsidio</a>
                    </li>
                    <li>
                        <a href="<?php echo URL::to('/admin/menu'); ?>"><i class="fa fa-fw fa-desktop"></i>Menu del dia</a>
                    </li>
                    <li>
                        <a href="<?php echo URL::to('/super/entrega'); ?>"><i class="fa fa-fw fa-wrench"></i> Entrega de Almuerzo</a>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-arrows-v"></i> Dropdown <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="#">Dropdown Item</a>
                            </li>
                            <li>
                                <a href="#">Dropdown Item</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-fw fa-file"></i> Historico de Almuerzo</a>
                    </li>
                    <!--<li>
                        <a href="index-rtl.html"><i class="fa fa-fw fa-dashboard"></i> RTL Dashboard</a>
                    </li>-->
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    
    
  

    <script src="<?php echo e(asset('/vendor/jquery/jquery.min.js')); ?>" charset="utf-8"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.min.js')); ?>" charset="utf-8"></script>
 
    <!-- Metis Menu Plugin JavaScript -->
 
    <script src="<?php echo e(asset('/vendor/metisMenu/metisMenu.min.js')); ?>" charset="utf-8"></script>
    <!-- Morris Charts JavaScript -->

    <script src="<?php echo e(asset('/vendor/raphael/raphael.min.js')); ?>" charset="utf-8"></script>

    <script src="<?php echo e(asset('/vendor/morrisjs/morris.min.js')); ?>" charset="utf-8"></script>

    <script src="<?php echo e(asset('/data/morris-data.js')); ?>" charset="utf-8"></script>
    <!-- Custom Theme JavaScript -->

    <script src="<?php echo e(asset('/js/sb-admin-2.js')); ?>" charset="utf-8"></script><!-- Este script despliega menu-->
    
    <script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>" charset="utf-8"></script>
    
     <script src="<?php echo e(asset('vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>" charset="utf-8"></script>


     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
   <script src="js/moment.min.js"></script>
   <script src="js/bootstrap-datetimepicker.min.js"></script>
   <script src="js/bootstrap-datetimepicker.es.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
      <script src="<?php echo e(asset('/tablas/scriptsearch.js')); ?>" charset="utf-8"></script>
</head>



    <script>
        $( document ).ready(function() {
            $('#fecha').datepicker({minDate: '0', dateFormat: 'YYYY-DD-MM' });
        });
    </script>
<!--<script >
      $( function() {
    $( "#fecha" ).datepicker();
    $( "#format" ).on( "change", function() {
      $( "#fecha" ).datepicker( "option", "dateFormat", "yy-mm-dd" );
    });
  } );
  </script>-->


     
     
     
     <script>
    $(document).ready(function() {
        $('#dataTables-User').DataTable({
            responsive: true,
            paging: true,
            searching: true
        });
    });
    </script>
   <script>
    $(document).ready(function() {
        $('#dataTables-servi').DataTable({
            responsive: true,
            paging: true,
            searching: true
        });
    });
    </script>
   <script>
    $('#type').change(function() {
    $('#carrera').hide();
    $('#subservi').hide();
  
        if ($(this).val() == 'estudiante') {
        $('#carrera').show();
             $('#subservi').show();
            $('#sub_id').show();
             $('#Servi_id').show();
          }if ($(this).val() == 'supervisor'){
              $('#carrera').hide();
              
              $('#subservi').hide();
            $('#x1').attr("value","supervisor");
              $('#x2').attr("value","supervisor");
              $('#x3').attr("value","Bienestar institucional UD");
              $('#carrera').attr('Bienestar supervisor');
          }if ($(this).val() == 'admin'){
               $('#carrera').hide();
              
              $('#subservi').hide();
               $('#x1').attr("value","");
              $('#x2').attr("value","");
              $('#carrera').attr("value","Admin site");
          }
        });


    </script>
   

</body>

</html>
