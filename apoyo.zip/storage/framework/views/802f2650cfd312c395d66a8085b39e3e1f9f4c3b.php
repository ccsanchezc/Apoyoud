<?php $__env->startSection('content'); ?>
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Dashboard <small>Statistics Overview</small>
                        </h1>
                    </div>
                </div>
                <!-- /.row -->


                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-comments fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e($menufecha); ?></div>
                                        <div>Almuerzos restantes!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-tasks fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e($subsidio); ?></div>
                                        <div>Tipo de Subsidio!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-money fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">124</div>
                                        <div>Saldo!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">Ver detalles</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-cutlery fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e($cantidad); ?></div>
                                        <div>Almuerzos pedidos!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">Ver detalles</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

                
                <!-- /.row -->
                <div class="row">

                <!-- Section Header -->
                
                <!-- Section Header End -->
 
                <div class="our-services">
             <div class="col-md-12 col-sm-12 col-xs-12 section-header1">
                    <h2><span class="page-header">Almuerzo del dia</span></h2>
                   
                    
                </div>
        
         <div class="row centered-form"> 
         <div class="col-md-5 col-sm-5 col-xs-5 text-xs-center col-center col-md-offset-1" >
                        <div class="panel">
                        <div class="col-md-10 col-sm-10 col-xs-10 text-xs-center col-center col-md-offset-1">
                            <div class="icon"> <h2>Sopa</h2>
                            </div> 
                            <p><?php echo e($sopa); ?></p>
                            <img src="home/images/sopa.jpg" alt="Custom Image">
                            </div> 
                        </div>

                            
</div>
                        <div class="col-md-5 col-sm-5 col-xs-5 text-xs-center col-center" >
                        <div class="panel">
                        <div class="col-md-10 col-sm-10 col-xs-10 text-xs-center col-center col-md-offset-1">
                            <div class="icon"> <h2>Plato fuerte</h2>
                            </div> 
                            <p><?php echo e($fuerte); ?></p>
                            <img src="home/images/fuerte.jpg" alt="Custom Image">
                            </div> 
                            </div> 
</div> 
</div>
</div>
 <div class="row centered-form">
                        <div class="col-md-5 col-sm-5 col-xs-5 text-xs-center col-center    col-md-offset-1" >
                        <div class="panel">
                        <div class="col-md-10 col-sm-10 col-xs-10 text-xs-center col-center col-md-offset-1">
                            <div class="icon"> <h2>Bebida</h2>
                            </div>
                            
                            <p><?php echo e($jugo); ?> </p>
                            <img src="home/images/bebida.jpg" alt="Custom Image">
                        </div>
                        </div>
</div>
                        <div class="col-md-5 col-sm-5 col-xs-5 text-xs-center col-center" >
                        <div class="panel">
                        <div class="col-md-10 col-sm-10 col-xs-10 text-xs-center col-center col-md-offset-1">
                            <div class="icon"> <h2>Postre</h2>
                            </div>
                            
                            <p><?php echo e($postre); ?> </p>
                            <img src="home/images/postre.jpg" alt="Custom Image">
                        </div>
                        </div>
</div>
                     
                    </div> 
                    </div>
                
            </div>
            </div>

            <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>