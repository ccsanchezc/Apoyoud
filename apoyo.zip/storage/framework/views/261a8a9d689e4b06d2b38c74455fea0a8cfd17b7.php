<?php if(Session::has('message')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
 <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span> </button>
 <?php echo e(Session::get('message')); ?>


</div>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Subsidios plataforma
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-responsive table-hover" id="dataTables-servi">
                                 <?php echo link_to_route('sub.create', 'Crear nuevo subsidio', null, ['class'=>'btn btn-success ']); ?>

                                <thead>
                                    <tr>
                                        <th>Tipo</th>
                                        <th>Descripción</th>
                                        <th>Operación</th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $subsidio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsidio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr class="gradeX">
                                        <td><?php echo e($subsidio->type); ?></td>
                                        <td><?php echo e($subsidio->descripcion); ?></td>
                                        <td class="center"><?php echo link_to_route('sub.edit', 'Editar', $subsidio->id,  ['class'=>'btn btn-primary']); ?>

                                        <?php echo link_to_route('sub.destroy', 'Eliminar', $subsidio->id,  ['onclick'=>"return confirm('¿Desea Eliminarlo?')" , 'class'=>'btn btn-danger']); ?>

                                      </td></td>
                                    </tr>
                                </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
          
        </div>
        <!-- /#page-wrapper -->

    </div>
    
    
    <!-- /#wrapper -->
    <!--<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>" charset="utf-8"></script>
    
     <script src="<?php echo e(asset('vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>" charset="utf-8"></script>-->
     
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>