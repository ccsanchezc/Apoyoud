<?php $__env->startSection('content'); ?>

<?php if(count($errors) > 0): ?>
   <div class="alert alert-danger" role="alert">
   <ul>
   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   		<li><?php echo e($error); ?></li>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </ul>
</div>
<?php endif; ?>

<div class="container">
      
        <div class="row centered-form">
        <div class="center">
        	<div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Registrar menú </h3>
			 			</div>
			 			<div class="panel-body">
			    		<?php echo Form::open(['route'=>'menu.store','method'=>'POST']); ?>

			    		    <div class="row">
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                      <div class="form-group">
                                     <?php echo Form::text('plato_fuerte',null,['id'=>'plato_fuerte', 'class'=>'form-control ','placeholder'=>'Plato fuerte']); ?>


                                    </div>
			    			    </div>  
                           		<div class="col-xs-6 col-sm-6 col-md-6">
                           		<div class="form-group">
                                         <?php echo Form::text('sopa',null,['id'=>'sopa', 'class'=>'form-control ','placeholder'=>'Sopa']); ?>



                                        </div>
			    				 </div>
			    				 <div class="col-xs-6 col-sm-6 col-md-6">
			    					<div class="form-group">
			    						<?php echo Form::text('postre',null,['id'=>'postre', 'class'=>'form-control','placeholder'=>'Postre']); ?>

			    					</div>
			    			    </div>
			    				<div class="col-xs-6 col-sm-6 col-md-6">
                                      <div class="form-group">
                                        <?php echo Form::text('jugo',null,['id'=>'jugo', 'class'=>'form-control','placeholder'=>'Jugo']); ?>

                                      </div>
                                 </div>
                              <div class="col-xs-6 col-sm-6 col-md-6">
                                       
                                         <?php echo Form::text('fecha',null,['id'=>'fecha','class'=>'form-control','placeholder'=>'Seleccione una fecha']); ?>


                                          </div>  
                    
			    				<div class="col-xs-6 col-sm-6 col-md-6">
			    				<div class="form-group">
			    	            <?php echo Form::text('cantitotal',null,['id'=>'cantitotal', 'class'=>'form-control','placeholder'=>'Cantidad total de almuerzos']); ?>

			    	       		 </div>
			    				</div>
                                </div>

                               <?php echo Form::submit('Registrar',['class'=>'btn btn-info btn-block']); ?>

			    			</div>
                       
			    		    
			    	    <?php echo Form::close(); ?>

			    	</div>
	    		</div>
    		</div>
    	</div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>