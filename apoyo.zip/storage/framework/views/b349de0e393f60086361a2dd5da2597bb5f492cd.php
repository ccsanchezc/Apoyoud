<?php $__env->startSection('content'); ?>
<!-- /.row -->
           
<?php if(Session::has('message')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
 <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span> </button>
 <?php echo e(Session::get('message')); ?>


</div>
<?php endif; ?>      
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Servicios plataforma
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                        <?php echo Form::open (['route' => 'servi.index', 'method' => 'GET', 'class' => 'navbar-form navbar-left pull-right','role' => 'search']); ?>

                                <div class="form-group">
                                <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Descripcion o Id']); ?>

                                    
                                </div>
                             <button type="submit" class="btn btn-default">Buscar</button>
                            <?php echo Form::close(); ?>


                            <table width="100%" class="table table-striped table-bordered table-responsive table-hover" id="dataTables-servi">
                                 <?php echo link_to_route('servi.create', 'Crear nuevo servicio', null, ['class'=>'btn btn-success ']); ?>

                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>Descripción</th>
                                        <th>Operación</th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $serviciosocial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr class="gradeX">
                                        <td><?php echo e($servis->nombre); ?></td>
                                        <td><?php echo e($servis->descripcion); ?></td>
                                        <td class="center"><?php echo link_to_route('servi.edit', 'Editar', $servis->id,  ['class'=>'btn btn-primary']); ?>

                                        <?php echo link_to_route('servi.destroy', 'Eliminar', $servis->id,  ['onclick'=>"return confirm('¿Desea Eliminarlo?')" , 'class'=>'btn btn-danger']); ?>

                                      </td></td>
                                    </tr>
                                </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <!-- /.table-responsive -->
                            <?php echo $serviciosocial->render(); ?>

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
          
        </div>
        <!-- /#page-wrapper -->

    </div>
    
    
    <!-- /#wrapper -->
    <!--<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>" charset="utf-8"></script>
    
     <script src="<?php echo e(asset('vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>" charset="utf-8"></script>-->
     
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>