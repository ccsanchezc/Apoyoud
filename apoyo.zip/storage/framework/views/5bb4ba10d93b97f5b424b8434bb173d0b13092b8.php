<?php if(Session::has('message')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
 <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span> </button>
 <?php echo e(Session::get('message')); ?>


</div>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Menú plataforma
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-responsive table-hover" id="dataTables-servi">
                                 <?php echo link_to_route('menu.create', 'Crear nuevo menú', null, ['class'=>'btn btn-success ']); ?>

                                <thead>
                                    <tr>
                                        <th>Plato Fuerte</th>
                                        <th>Sopa</th>
                                        <th>Postre</th>
                                        <th>Jugo</th>
                                        <th>Cantidad total</th>
                                        <th>Fecha</th>
                                        <th>Operación</th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr class="gradeX">
                                        <td><?php echo e($menu->sopa); ?></td>
                                        <td><?php echo e($menu->plato_fuerte); ?></td>
                                        <td><?php echo e($menu->jugo); ?></td>
                                        <td><?php echo e($menu->postre); ?></td>
                                        <td><?php echo e($menu->cantitotal); ?></td>
                                        <td><?php echo e($menu->fecha); ?></td>
                                        <td class="center"><?php echo link_to_route('menu.edit', 'Editar', $menu->id,  ['class'=>'btn btn-primary']); ?>

                                        <?php echo link_to_route('menu.destroy', 'Eliminar', $menu->id,  ['onclick'=>"return confirm('¿Desea Eliminarlo?')" , 'class'=>'btn btn-danger']); ?>

                                      </td></td>
                                    </tr>
                                </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
          
        </div>
        <!-- /#page-wrapper -->

    </div>
    
    
    <!-- /#wrapper -->
    <!--<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>" charset="utf-8"></script>
    
     <script src="<?php echo e(asset('vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>" charset="utf-8"></script>-->
     
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>